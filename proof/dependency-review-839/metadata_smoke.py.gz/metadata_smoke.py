from pathlib import Path
import importlib_metadata as metadata
import sys
import tempfile
if sys.version_info[:2] != (3, 11): raise ValueError("Unexpected test interpreter")
if metadata.version("importlib-metadata") != "9.0.1": raise ValueError("Unexpected installed metadata package")
if metadata.version("pytest") != "9.0.3": raise ValueError("Unexpected installed pytest")
if not any(ep.name == "pytest_cov" for ep in metadata.entry_points(group="pytest11")): raise ValueError("Coverage plugin discovery failed")
with tempfile.TemporaryDirectory() as empty:
    try:
        metadata.Distribution.at(Path(empty)).metadata
    except metadata.MetadataNotFound:
        pass
    else:
        raise ValueError("Missing distribution metadata did not fail explicitly")
print("Python3.11 metadata versions, pytest plugin discovery and explicit missing-metadata behavior pass")
