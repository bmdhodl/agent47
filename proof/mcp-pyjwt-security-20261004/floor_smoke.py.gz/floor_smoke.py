import base64
import importlib.metadata as metadata
import os
import sys
from pathlib import Path
import jwt
from agentguard_mcp.server import create_server
if sys.version_info[:2] != (3,10): raise ValueError("Wrong floor interpreter")
if metadata.version("mcp") != "1.30.0": raise ValueError("MCP1 changed")
if metadata.version("PyJWT") != "2.15.1": raise ValueError("JWT differs from tested lock")
os.environ["AGENTGUARD_DB_PATH"] = str(Path(sys.argv[1]) / "floor-state.db")
if create_server() is None: raise ValueError("Server initialization failed")
header = base64.urlsafe_b64encode(b'{"alg":"HS256","typ":"JWT"}').rstrip(b"=")
payload = base64.urlsafe_b64encode(b"["*20000+b"]"*20000).rstrip(b"=")
token = (header+b"."+payload+b".Zm9yZ2Vk").decode("ascii")
for use_lookup in [False, True]:
    try:
        if use_lookup: jwt.PyJWKClient("https://example.invalid/jwks").get_signing_key_from_jwt(token)
        else: jwt.decode(token,options={"verify_signature":False})
    except jwt.DecodeError: pass
    else: raise ValueError("Nested token was accepted")
print("Installed Python3.10 MCP1 server and both JWT malformed-payload paths pass")
