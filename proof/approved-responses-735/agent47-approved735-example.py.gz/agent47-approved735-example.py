import gzip
import hashlib
import json
import os
import shutil
import subprocess
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

ROOT = Path(r"C:\Users\patri\Documents\GitHub\agent47-review-20261002")
BASE = Path(r"C:\Users\patri\.codex\tmp\agent47-approved735-build")
PROOF = ROOT / "proof/approved-responses-735"
receipt = json.loads((PROOF / "receipt.json").read_text())
receipt["commands"] = [r for r in receipt["commands"] if r["name"] not in ("floor-example", "current-example")]

class Handler(BaseHTTPRequestHandler):
    def do_POST(self):
        self.rfile.read(int(self.headers["Content-Length"]))
        self.server.calls += 1
        n = self.server.calls
        body = {"id": f"resp_{n}", "object": "response", "created_at": 0,
                "status": "completed", "model": "gpt-4o-mini",
                "output": [{"type": "function_call", "id": f"fc_{n}",
                            "call_id": f"call_{n}", "name": "search_docs",
                            "arguments": '{"query": "LoopGuard"}', "status": "completed"}],
                "parallel_tool_calls": True, "tool_choice": "auto", "tools": [],
                "usage": {"input_tokens": 40000, "input_tokens_details": {"cached_tokens": 0},
                          "output_tokens": 10000, "output_tokens_details": {"reasoning_tokens": 0},
                          "total_tokens": 50000}}
        data = json.dumps(body).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)
    def log_message(self, *args):
        pass

for profile in ("floor", "current"):
    cwd = BASE / (profile + "-example")
    cwd.mkdir(exist_ok=True)
    example = cwd / "openai_agents_sdk_budget.py"
    shutil.copyfile(ROOT / "examples/openai_agents_sdk_budget.py", example)
    server = HTTPServer(("127.0.0.1", 0), Handler)
    server.calls = 0
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    env = {k: v for k, v in os.environ.items() if not any(s in k.upper() for s in
           ("OPENAI", "ANTHROPIC", "GEMINI", "API_KEY", "TOKEN", "PYTHONPATH", "PYTHONHOME", "PIP_", "UV_"))}
    env.update(OPENAI_API_KEY="fake-local-test", OPENAI_BASE_URL=f"http://127.0.0.1:{server.server_port}/v1",
               OPENAI_AGENTS_DISABLE_TRACING="1", PYTHONUTF8="1")
    argv = [str(BASE / profile / "Scripts/python.exe"), str(example)]
    try:
        result = subprocess.run(argv, cwd=cwd, env=env, capture_output=True,
                                creationflags=subprocess.CREATE_NO_WINDOW)
    finally:
        server.shutdown()
        thread.join()
        server.server_close()
    output = result.stdout + result.stderr
    if result.returncode or server.calls != 5 or b"Recorded $0.0600 over 5 model calls" not in output or b"AgentGuard stopped the run:" not in output:
        raise ValueError(f"Example failed for {profile}: {output!r}, requests={server.calls}")
    output += f"\nFake local transport received {server.calls} requests; no sixth dispatch.\n".encode()
    name = profile + "-example.log.gz"
    data = gzip.compress(output, mtime=0)
    (PROOF / name).write_bytes(data)
    receipt["artifacts"][name] = hashlib.sha256(data).hexdigest()
    receipt["commands"].append(dict(name=profile + "-example", argv=argv, cwd=str(cwd), exit=result.returncode))
    trace = gzip.compress((cwd / "agents_traces.jsonl").read_bytes(), mtime=0)
    name = profile + "-example-trace.jsonl.gz"
    (PROOF / name).write_bytes(trace)
    receipt["artifacts"][name] = hashlib.sha256(trace).hexdigest()
    print(profile, output.decode(), flush=True)

for profile in ("floor", "current"):
    for suite, original in (("responses", profile + ".xml"), ("free-local", profile + "-free.xml")):
        name = profile + "-" + suite + ".xml.gz"
        data = gzip.compress((BASE / original).read_bytes(), mtime=0)
        (PROOF / name).write_bytes(data)
        receipt["artifacts"][name] = hashlib.sha256(data).hexdigest()
for attempt in receipt["failed_attempts"]:
    name = attempt["log"] + ".gz"
    data = gzip.compress((BASE / attempt["log"]).read_bytes(), mtime=0)
    (PROOF / name).write_bytes(data)
    receipt["artifacts"][name] = hashlib.sha256(data).hexdigest()
receipt["verifier_sha256"] = hashlib.sha256((PROOF / "verify.py").read_bytes()).hexdigest()
(PROOF / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8", newline="\n")
