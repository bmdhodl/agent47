import datetime
import gzip
import hashlib
import json
import os
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(r'C:\Users\patri\Documents\GitHub\agent47-review-20261002')
BASE = Path(r'C:\Users\patri\.codex\tmp\agent47-approved735-build')
TOOLS = Path(r'C:\Users\patri\.codex\tmp\agent47-mcp-pyjwt-build\patched\Scripts\python.exe')
PY311 = Path(r'C:\Users\patri\AppData\Local\Programs\Python\Python311\python.exe')
PROOF = ROOT / 'proof/approved-responses-735'
BASE.mkdir(exist_ok=True)
PROOF.mkdir(exist_ok=True)
commands_path = BASE / 'commands.json'
commands = json.loads(commands_path.read_text()) if commands_path.exists() else []
failed_path = BASE / 'failed-attempts.json'
failed_attempts = json.loads(failed_path.read_text()) if failed_path.exists() else []
for row in list(commands):
    if row['exit']:
        failed_log = BASE / (row['name'] + '-initial-failure.log')
        shutil.copyfile(BASE / (row['name'] + '.log'), failed_log)
        row['log'] = failed_log.name
        failed_attempts.append(row)
        commands.remove(row)
failed_path.write_text(json.dumps(failed_attempts, indent=2) + '\n', encoding='utf-8')
env = {k: v for k, v in os.environ.items() if not any(s in k.upper() for s in
       ('OPENAI', 'ANTHROPIC', 'GEMINI', 'API_KEY', 'TOKEN', 'PYTHONPATH', 'PYTHONHOME', 'PIP_', 'UV_'))}
env.update(PYTHONUTF8='1', OPENAI_AGENTS_DISABLE_TRACING='1', AGENTGUARD_REQUIRE_REAL_DEPS='1')

def run(name, argv, cwd=ROOT, source=False):
    prior = next((r for r in commands if r['name'] == name and r['exit'] == 0), None)
    if prior:
        return
    selected_env = dict(env)
    if source:
        selected_env['PYTHONPATH'] = str(ROOT / 'sdk')
        selected_env.pop('AGENTGUARD_REQUIRE_REAL_DEPS', None)
    result = subprocess.run([str(x) for x in argv], cwd=cwd, env=selected_env,
                            capture_output=True, creationflags=subprocess.CREATE_NO_WINDOW)
    (BASE / (name + '.log')).write_bytes(result.stdout + result.stderr)
    row = {'name': name, 'argv': [str(x) for x in argv], 'cwd': str(cwd), 'exit': result.returncode,
           'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    commands.append(row)
    commands_path.write_text(json.dumps(commands, indent=2) + '\n', encoding='utf-8', newline='\n')
    print(name, result.returncode, flush=True)
    if result.returncode:
        print((result.stdout + result.stderr).decode('utf-8', errors='replace')[-2200:], flush=True)
        raise SystemExit(result.returncode)

run('candidate-build', [TOOLS, '-m', 'build', '--wheel', '--outdir', BASE / 'dist', ROOT / 'sdk'])
wheel = next((BASE / 'dist').glob('agentguard47-2.0.0-*.whl'))
tests = BASE / 'installed-tests'
(tests / 'fixtures').mkdir(parents=True, exist_ok=True)
for name in ['test_real_dispatch.py', 'test_free_local_clients.py', 'fixtures/__init__.py', 'fixtures/usage_payloads.py']:
    data = subprocess.check_output(['git', 'show', 'HEAD:sdk/tests/' + name], cwd=ROOT,
                                   creationflags=subprocess.CREATE_NO_WINDOW)
    (tests / name).write_bytes(data)

installed_probe = BASE / 'installed-probe.py'
installed_probe.write_text('''import hashlib, importlib.metadata as m, json, os, platform, sys, zipfile
from pathlib import Path
import agentguard
w=Path(sys.argv[1]); checkout=Path(sys.argv[2]); dst=Path(sys.argv[3]); d=m.distribution('agentguard47')
origin=Path(agentguard.__file__).resolve()
if checkout.resolve() in origin.parents: raise ValueError('Imported repository instead of installed wheel')
count=0
with zipfile.ZipFile(w) as archive:
    if archive.testzip() is not None: raise ValueError('Corrupt wheel')
    for name in archive.namelist():
        if name.startswith('agentguard/') and name.endswith('.py'):
            data=archive.read(name)
            if Path(d.locate_file(name)).read_bytes()!=data: raise ValueError('Installed wheel mismatch: '+name)
            if (checkout/'sdk'/name).read_bytes()!=data: raise ValueError('Wheel/source mismatch: '+name)
            count+=1
    metadata_name=next(n for n in archive.namelist() if n.endswith('.dist-info/METADATA'))
    if Path(d.locate_file(metadata_name)).read_bytes()!=archive.read(metadata_name): raise ValueError('Metadata differs')
if count<40: raise ValueError('Incomplete package inventory')
mandatory=[r for r in d.requires or [] if 'extra ==' not in r]
if mandatory: raise ValueError('Core runtime dependencies added')
out=dict(version=d.version,python=platform.python_version(),system=platform.system(),origin=str(origin),
    package_files_equal_wheel_and_source=count,metadata_equal_wheel=True,mandatory_runtime_requirements=0,
    openai=m.version('openai'),agents=m.version('openai-agents'),wheel_sha256=hashlib.sha256(w.read_bytes()).hexdigest())
dst.write_text(json.dumps(out,indent=2)+'\\n',encoding='utf-8',newline='\\n');print(json.dumps(out))
''', encoding='utf-8', newline='\n')

profiles = []
for profile, python, pair in [('floor', PY311, ['openai==1.66.3', 'openai-agents==0.0.3']),
                             ('current', PY311, ['openai==3.22.1', 'openai-agents==0.22.3'])]:
    venv = BASE / profile
    interpreter = venv / 'Scripts/python.exe'
    run(profile + '-venv', [python, '-m', 'venv', venv])
    run(profile + '-providers', [interpreter, '-I', '-m', 'pip', '--isolated', 'install',
                                 '--index-url', 'https://pypi.org/simple', *pair, 'pytest==9.0.3'])
    run(profile + '-wheel', [interpreter, '-I', '-m', 'pip', '--isolated', 'install', '--no-deps', wheel])
    run(profile + '-pip-check', [interpreter, '-I', '-m', 'pip', '--isolated', 'check'])
    run(profile + '-inventory', [interpreter, '-I', installed_probe, wheel, ROOT, BASE / (profile + '-installed.json')], cwd=tests)
    run(profile + '-responses', [interpreter, '-m', 'pytest', 'test_real_dispatch.py', '-q', '-p', 'no:cacheprovider',
                                 '-k', 'responses or agents_sdk', '--junitxml', BASE / (profile + '.xml'),
                                 '--basetemp', BASE / (profile + '-pytest')], cwd=tests)
    run(profile + '-free-local', [interpreter, '-m', 'pytest', 'test_free_local_clients.py', '-q', '-p', 'no:cacheprovider',
                                  '--junitxml', BASE / (profile + '-free.xml'),
                                  '--basetemp', BASE / (profile + '-free-pytest')], cwd=tests)
    profile_receipt = json.loads((BASE / (profile + '-installed.json')).read_text())
    suites = list(ET.parse(BASE / (profile + '.xml')).getroot().iter('testsuite'))
    counts = {k: sum(int(s.get(k, '0')) for s in suites) for k in ('tests', 'skipped', 'failures', 'errors')}
    if counts['tests'] < 13 or any(counts[k] for k in ('skipped', 'failures', 'errors')):
        raise ValueError('Installed Responses suite did not run cleanly: ' + profile)
    profile_receipt['responses_suite'] = counts
    profiles.append(profile_receipt)

readme = '''# Owner-approved AG-06 acceptance

The accepted architecture uses the existing init/patch APIs and the standard
OpenAIResponsesModel. The candidate is 2.0.0 and remains unpublished; stable
PyPI 1.4.0 does not provide this path. Fresh installed Windows/Python 3.11
minimum/current OpenAI and Agents SDK pairs run outside the checkout with real
SDK objects, fake counting transport, disabled vendor tracing and no paid calls.
Native max_turns remains effective; unsupported boundaries are documented in
docs/integrations/openai-responses.md and the enforcement map.

receipt.json binds commands, actual version pairs, installed package/metadata
identity, zero mandatory runtime dependencies and exact source/test snapshots.
The private installation resolves allowed transitives normally; it does not
claim that the Linux CI locks are generic Windows locks. Gzipped logs and the
candidate wheel retain exact bytes. Hosted exact-head CI and independent PR
review remain separate merge gates. Internal dogfood and outside adoption are
separate; no Fluarmn or external-user success is inferred from these tests.

Run python proof/approved-responses-735/verify.py for artifact verification.
OpenAI | GPT-6 | auto.
'''
(PROOF / 'README.md').write_text(readme, encoding='utf-8', newline='\n')
run('source-full', [TOOLS, '-m', 'pytest', 'sdk/tests', '-q', '-p', 'no:cacheprovider',
                    '--cov=agentguard', '--cov-fail-under=80', '--basetemp', BASE / 'source-pytest'], source=True)
run('source-ruff', [TOOLS, '-m', 'ruff', 'check', 'sdk/agentguard', 'scripts/generate_pypi_readme.py',
                    'scripts/sdk_preflight.py', 'scripts/sdk_release_guard.py', 'scripts/ci_tools_requirements_guard.py',
                    'scripts/review_readiness_guard.py', 'scripts/live_cost_reconcile.py', 'scripts/check_ci_results.py',
                    'sdk/tests/test_ci_results.py', 'examples/openai_agents_sdk_budget.py'])
run('source-bandit', [TOOLS, '-m', 'bandit', '-r', 'sdk/agentguard', '-s', 'B101,B110,B112,B311', '-q'])
for name, script, extra in [('source-docs', 'scripts/check_docs.py', ['--repository', 'agent47']),
                             ('source-release', 'scripts/sdk_release_guard.py', []),
                             ('source-tools', 'scripts/ci_tools_requirements_guard.py', []),
                             ('source-review', 'scripts/review_readiness_guard.py', [])]:
    run(name, [TOOLS, script, *extra])

shutil.copyfile(wheel, PROOF / wheel.name)
artifacts = {wheel.name: hashlib.sha256(wheel.read_bytes()).hexdigest()}
for row in commands:
    name = row['name'] + '.log.gz'
    data = gzip.compress((BASE / (row['name'] + '.log')).read_bytes(), mtime=0)
    (PROOF / name).write_bytes(data)
    artifacts[name] = hashlib.sha256(data).hexdigest()
source_hashes = {}
paths = [p.relative_to(ROOT).as_posix() for p in (ROOT / 'sdk/agentguard').rglob('*.py')]
paths += ['sdk/pyproject.toml', 'sdk/tests/test_real_dispatch.py', 'sdk/tests/test_free_local_clients.py',
          'sdk/tests/fixtures/usage_payloads.py', 'examples/openai_agents_sdk_budget.py',
          'docs/integrations/openai-responses.md', 'memory/decisions.md']
for index, path in enumerate(sorted(paths)):
    data = (ROOT / path).read_bytes().replace(b'\r\n', b'\n')
    digest = hashlib.sha256(data).hexdigest()
    source_hashes[path] = digest
    name = f'source-{index:02d}.gz'
    archived = gzip.compress(data, mtime=0)
    (PROOF / name).write_bytes(archived)
    artifacts[name] = hashlib.sha256(archived).hexdigest()
receipt = {'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'commands': commands,
           'failed_attempts': failed_attempts,
           'profiles': profiles, 'source_hashes': source_hashes, 'artifacts': artifacts,
           'acceptance': 'Existing approved Responses/Agents API, minimum/current installed candidate behavior, native max_turns and explicit unsupported boundaries.',
           'limits': 'No release, workflow/security change, broad adapter approval or external-adoption claim. Fluarmn dogfood is evaluated separately.'}
(PROOF / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Installed candidate and source acceptance complete', flush=True)
